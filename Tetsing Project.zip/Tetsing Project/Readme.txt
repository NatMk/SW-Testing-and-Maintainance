How to run this project
This is Netbeans IDE project, so just run Netbeans -> File -> Open project -> browse project
folder -> Open Project.

JUnit library must be loaded automatically, but if not, do the following:
Right click on project -> Properties -> Libraries -> Add library -> Import -> JUnit ->
Import Library -> Add Library -> Ok.

To run tests just right click on PrinttokenTest.java -> Run file.